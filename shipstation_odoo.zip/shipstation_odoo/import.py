import os
import glob
import pandas as pd
import xmlrpc.client
import configparser

# === Load Odoo credentials ===
config = configparser.ConfigParser()
config.read('config.ini')

url = config['odoo']['url']
db = config['odoo']['db']
username = config['odoo']['username']
password = config['odoo']['password']

# === Find the latest CSV in Downloads ===
downloads_dir = os.path.expanduser("~/Downloads")
csv_files = glob.glob(os.path.join(downloads_dir, "*.csv"))
latest_csv = max(csv_files, key=os.path.getmtime)

# === Load and clean CSV ===
df = pd.read_csv(latest_csv)
df.columns = df.columns.str.strip()  # remove leading/trailing whitespace from column names

# === Set up XML-RPC connection to Odoo ===
common = xmlrpc.client.ServerProxy(f"{url}/xmlrpc/2/common")
uid = common.authenticate(db, username, password, {})
models = xmlrpc.client.ServerProxy(f"{url}/xmlrpc/2/object")

# === Helpers ===
def find_or_create_partner(name):
    ids = models.execute_kw(db, uid, password, 'res.partner', 'search', [[['name', '=', name]]])
    return ids[0] if ids else models.execute_kw(db, uid, password, 'res.partner', 'create', [{'name': name}])

def find_or_create_product(name):
    ids = models.execute_kw(db, uid, password, 'product.product', 'search', [[['name', '=', name]]])
    return ids[0] if ids else models.execute_kw(db, uid, password, 'product.product', 'create', [{'name': name}])

# === Process and confirm sale orders ===
for order_number, group in df.groupby('Order - Number'):
    customer_name = group['Ship To - Name'].iloc[0]
    partner_id = find_or_create_partner(customer_name)

    order_id = models.execute_kw(db, uid, password, 'sale.order', 'create', [{
        'partner_id': partner_id,
        'client_order_ref': str(order_number),
    }])

    for _, row in group.iterrows():
        product_id = find_or_create_product(row['Item - Name'])
        quantity = int(row['Item - Qty'])
        unit_price = float(row['Item - Price'])

        models.execute_kw(db, uid, password, 'sale.order.line', 'create', [{
            'order_id': order_id,
            'product_id': product_id,
            'product_uom_qty': quantity,
            'price_unit': unit_price,
            'name': row['Item - Name'],
        }])

    models.execute_kw(db, uid, password, 'sale.order', 'action_confirm', [[order_id]])
    print(f"Confirmed sale order {order_number} for {customer_name} with {len(group)} line(s).")

print("All orders processed and confirmed.")
